Readme file for H1_L1_demo
===========================
1. Copy files below to this folder:
 
L-L1_LOSC_4_V1-1126257414-4096.hdf5
H-H1_LOSC_4_V1-1126257414-4096.hdf5

2. H1_L1_demo_1.py

computes power in 60*n Hz tones and in the region 50-300Hz
grep for string "Changes"
 grep for string "demo_1" and set it to 1 or 2

3. H1_demo_filter.py

  Bandpass filter 40-900Hz
 grep for string "Changes"



4. H1_demo_filter_2.py

  Inject H1 signal in 20-300Hz region along with same signal frequency upshifted by 500Hz.
 in a block 10 seconds before tevent
 and then filtered by 2 bandpass filters: [1] 20-300Hz [2] 20-900Hz
 grep for string "Changes"

5. H1_demo_whiten.py

  Inject 50 Hz sine wave signal 10 seconds before "tevent" and see effect of whitening.
 grep for string "Changes"
